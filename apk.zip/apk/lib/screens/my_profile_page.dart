import 'package:flutter/material.dart';

import '../shared_prefs_helper.dart';

class MyProfilePage extends StatefulWidget {
  const MyProfilePage({super.key});

  @override
  _MyProfilePageState createState() => _MyProfilePageState();
}

class _MyProfilePageState extends State<MyProfilePage> {
  List<Map<String, String>> users = [];

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  /// Function to load users from SharedPrefsHelper
  Future<void> _loadUsers() async {
    List<Map<String, String>> loadedUsers = await SharedPrefsHelper.getUsers();
    setState(() {
      users = loadedUsers;
    });
  }

  Color _getRowColor(String status) {
    return status == "Active" ? Colors.green[100]! : Colors.red[100]!;
  }

  Icon _getStatusIcon(String status) {
    return status == "Active"
        ? Icon(Icons.check_circle, color: Colors.green)
        : Icon(Icons.cancel, color: Colors.red);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Profile")),
      body: users.isEmpty
          ? Center(child: Text("No users registered yet."))
          : ListView.builder(
        itemCount: users.length,
        itemBuilder: (context, index) {
          return Container(
            color: _getRowColor(users[index]['status']!),
            margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
            child: ListTile(
              leading: _getStatusIcon(users[index]['status']!),
              title: Text(users[index]['name']!, style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(users[index]['email']!),
            ),
          );
        },
      ),
    );
  }
}
