import 'package:flutter/material.dart'; // Import the helper
import '../shared_prefs_helper.dart';
import 'my_profile_page.dart'; // Import MyProfilePage

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  bool _isActive = true;

  /// Function to save user using SharedPrefsHelper
  Future<void> _saveUser() async {
    if (!_formKey.currentState!.validate()) return;

    await SharedPrefsHelper.saveUser(
      _nameController.text,
      _emailController.text,
      _isActive,
    );

    _nameController.clear();
    _emailController.clear();
    setState(() {});

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("User registered successfully")),
    );
  }

  String? _validateName(String? value) {
    return (value == null || value.isEmpty) ? "Please enter your name" : null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) return "Please enter your email";
    String emailPattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    return !RegExp(emailPattern).hasMatch(value) ? "Enter a valid email" : null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Register")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(labelText: "Name"),
                validator: _validateName,
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(labelText: "Email"),
                validator: _validateEmail,
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Text("Status: "),
                  Radio(
                    value: true,
                    groupValue: _isActive,
                    onChanged: (bool? value) => setState(() => _isActive = value!),
                  ),
                  Text("Active"),
                  Radio(
                    value: false,
                    groupValue: _isActive,
                    onChanged: (bool? value) => setState(() => _isActive = value!),
                  ),
                  Text("Inactive"),
                ],
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: _saveUser,
                child: Text("Register"),
              ),
              TextButton(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MyProfilePage()),
                ),
                child: Text("Go to My Profile"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
