import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefsHelper {
  static const String _usersKey = 'users';

  /// Saves a new user to SharedPreferences
  static Future<void> saveUser(String name, String email, bool isActive) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String status = isActive ? "Active" : "Inactive";

    List<String> users = await getUsersAsStringList();
    users.add('$name,$email,$status');

    await prefs.setStringList(_usersKey, users);
  }

  /// Loads users from SharedPreferences and returns a list of maps
  static Future<List<Map<String, String>>> getUsers() async {
    List<String> storedUsers = await getUsersAsStringList();

    return storedUsers.map((user) {
      List<String> data = user.split(',');
      return {'name': data[0], 'email': data[1], 'status': data[2]};
    }).toList();
  }

  /// Helper function to get users as a list of strings
  static Future<List<String>> getUsersAsStringList() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_usersKey) ?? [];
  }
}
